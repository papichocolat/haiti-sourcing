// =============================================
// Haiti Sourcing — Main JS
// All 42 products from Lakay Pa Lwen, -$1 each
// Port-au-Prince delivery only
// Images: Unsplash free licensed
// =============================================

const PRODUCTS = [
  // STAPLES & GRAINS
  { name: "White Rice 4.5 Mamit",        price: 18.00, orig: 19.00, cat: "staples",    img: "https://images.unsplash.com/photo-1586201375761-83865001e31c?w=400&q=80", desc: "Clean, high-quality white rice for all types of dishes." },
  { name: "Riz 9 Mamit (Gwo Sak)",       price: 39.00, orig: 40.00, cat: "staples",    img: "https://images.unsplash.com/photo-1536304993881-ff86e0c9b0b4?w=400&q=80", desc: "Large bag of quality rice, ideal for family cooking." },
  { name: "Diri Shella (Mamit)",         price: 14.00, orig: 15.00, cat: "staples",    img: "https://images.unsplash.com/photo-1594756202469-9ff9799b2e4e?w=400&q=80", desc: "Traditional dried rice flakes, perfect for Haitian meals." },
  { name: "Spaghetti (Kes)",             price: 16.00, orig: 17.00, cat: "staples",    img: "https://images.unsplash.com/photo-1551462147-ff29053bfc14?w=400&q=80", desc: "High-quality spaghetti, perfect for quick family meals." },
  { name: "Macaroni KèS",                price: 12.00, orig: 13.00, cat: "staples",    img: "https://images.unsplash.com/photo-1621996346565-e3dbc646d9a9?w=400&q=80", desc: "Quality macaroni pasta ideal for a variety of dishes." },
  { name: "Mamit Ble",                   price: 11.00, orig: 12.00, cat: "staples",    img: "https://images.unsplash.com/photo-1574323347407-f5e1ad6d020b?w=400&q=80", desc: "Whole wheat grain, a nutritious household staple." },
  { name: "Mamit Avwàn",                 price: 10.00, orig: 11.00, cat: "staples",    img: "https://images.unsplash.com/photo-1614961233913-a5113a4a34ed?w=400&q=80", desc: "Oats for a healthy, filling breakfast." },
  { name: "Mamit Farine",                price:  6.50, orig:  7.50, cat: "staples",    img: "https://images.unsplash.com/photo-1627485937980-221c88ac04f9?w=400&q=80", desc: "Quality flour for baking and everyday cooking." },
  { name: "MAYI MOULEN (Mamit)",         price:  8.00, orig:  9.00, cat: "staples",    img: "https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=400&q=80", desc: "Finely ground corn flour perfect for traditional cooking." },
  { name: "Pitimi (1 Mamit)",            price: 11.00, orig: 12.00, cat: "staples",    img: "https://images.unsplash.com/photo-1500382017468-9049fed747ef?w=400&q=80", desc: "Traditional sorghum grain, a Haitian household essential." },
  { name: "Red Beans (Mamit)",           price: 10.50, orig: 11.50, cat: "staples",    img: "https://images.unsplash.com/photo-1615485290382-441e4d049cb5?w=400&q=80", desc: "High-quality red beans (Pwa wouj), rich in protein." },
  { name: "Black Beans (Pwa Nwa) Mamit", price:  7.00, orig:  8.00, cat: "staples",    img: "https://images.unsplash.com/photo-1628711238898-da2d0ac3b5e3?w=400&q=80", desc: "Quality black beans perfect for traditional Haitian dishes." },
  { name: "Corn Flakes",                 price:  5.00, orig:  6.00, cat: "staples",    img: "https://images.unsplash.com/photo-1549366021-9f761d040a94?w=400&q=80", desc: "Crispy corn flakes, perfect for a healthy breakfast." },
  { name: "Sugar (Mamit)",               price:  9.00, orig: 10.00, cat: "staples",    img: "https://images.unsplash.com/photo-1550159930-40066082a4fc?w=400&q=80", desc: "Fine-quality sugar for cooking, baking, and beverages." },

  // DAIRY & EGGS
  { name: "Alaska Milk 900g",            price: 18.50, orig: 19.50, cat: "dairy",      img: "https://images.unsplash.com/photo-1563636619-e9143da7973b?w=400&q=80", desc: "High-quality powdered milk, rich in nutrients." },
  { name: "Bongu Milk 9 CT",             price:  7.00, orig:  8.00, cat: "dairy",      img: "https://images.unsplash.com/photo-1550583724-b2692b85b150?w=400&q=80", desc: "Rich and tasty milk, great for drinking and cooking." },
  { name: "Lait Bongu Kès (48 unités)",  price: 29.00, orig: 30.00, cat: "dairy",      img: "https://images.unsplash.com/photo-1600718374662-0483d2b9da44?w=400&q=80", desc: "Bulk pack of 48 Bongu milk cartons for the whole family." },
  { name: "Bongu Shake 3 CT",            price:  6.00, orig:  7.00, cat: "dairy",      img: "https://images.unsplash.com/photo-1572490122747-3968b75cc699?w=400&q=80", desc: "Delicious shakes in chocolate, vanilla, and strawberry." },
  { name: "Cheese (La Vache Qui Rit)",   price:  3.00, orig:  4.00, cat: "dairy",      img: "https://images.unsplash.com/photo-1486297678162-eb2a19b0a32d?w=400&q=80", desc: "Creamy cheese, perfect for snacks, sandwiches, and meals." },
  { name: "KATON ZE",                    price:  9.00, orig: 10.00, cat: "dairy",      img: "https://images.unsplash.com/photo-1582722872445-44dc5f7e3c8f?w=400&q=80", desc: "100% fresh eggs (Zè yo 100% frè)." },

  // MEAT & FISH
  { name: "Smoked Salami (Induveca)",    price:  6.00, orig:  7.00, cat: "meat",       img: "https://images.unsplash.com/photo-1612871689948-8b6012acb9a9?w=400&q=80", desc: "Rich smoked salami, perfect for sandwiches and meals.", popular: true },
  { name: "VYANN BèF",                   price: 19.00, orig: 20.00, cat: "meat",       img: "https://images.unsplash.com/photo-1529692236671-f1f6cf9683ba?w=400&q=80", desc: "Quality beef — rich in protein, iron, and vitamins." },
  { name: "KWIS POUL (12 CT)",           price:  9.50, orig: 10.50, cat: "meat",       img: "https://images.unsplash.com/photo-1587593810167-a84920ea0781?w=400&q=80", desc: "Fresh, high-quality chicken thighs (Poul frè ak bon kalite)." },
  { name: "PYE POUL (30 CT)",            price:  9.00, orig: 10.00, cat: "meat",       img: "https://images.unsplash.com/photo-1501200291289-c5a76c232e5f?w=400&q=80", desc: "Fresh chicken feet, 30 pieces (Poul ki frè ak bon kalite)." },
  { name: "ZEL POUL (14 CT)",            price:  6.00, orig:  7.00, cat: "meat",       img: "https://images.unsplash.com/photo-1527477396000-e27163b481c2?w=400&q=80", desc: "Fresh chicken wings, quality guaranteed." },
  { name: "ARANSO 6 CT",                 price:  9.00, orig: 10.00, cat: "meat",       img: "https://images.unsplash.com/photo-1510130387422-82bed34b37e9?w=400&q=80", desc: "Freshly prepared dried fish, perfect for traditional dishes." },
  { name: "Somon",                       price:  3.50, orig:  4.50, cat: "meat",       img: "https://images.unsplash.com/photo-1519708227418-c8fd9a32b7a2?w=400&q=80", desc: "Quality salmon product for everyday meals." },

  // CONDIMENTS & PANTRY
  { name: "Cooking Oil",                 price: 14.00, orig: 15.00, cat: "condiments", img: "https://images.unsplash.com/photo-1474979266404-7eaacbcd87c5?w=400&q=80", desc: "High-quality oil ideal for frying and daily cooking." },
  { name: "Ketchup MAMIT",               price:  4.00, orig:  5.00, cat: "condiments", img: "https://images.unsplash.com/photo-1571680323029-c1c1b7f6e0f8?w=400&q=80", desc: "Classic tomato ketchup loved by all ages." },
  { name: "Mayonnaise MAMIT",            price: 12.00, orig: 13.00, cat: "condiments", img: "https://images.unsplash.com/photo-1604935067011-b8aa9a6a7861?w=400&q=80", desc: "Smooth creamy mayonnaise for sandwiches and salads." },
  { name: "Tomato Paste MAMIT",          price: 12.00, orig: 13.00, cat: "condiments", img: "https://images.unsplash.com/photo-1518977676601-b53f82aba655?w=400&q=80", desc: "Rich tomato paste for sauces and traditional dishes." },
  { name: "Maggi (El Criollito) 60 CT",  price:  5.00, orig:  6.00, cat: "condiments", img: "https://images.unsplash.com/photo-1596040033229-a9821ebd058d?w=400&q=80", desc: "Popular seasoning to enhance the flavor of your meals." },
  { name: "Maggi with Tomato 36 CT",     price:  3.00, orig:  4.00, cat: "condiments", img: "https://images.unsplash.com/photo-1625944525533-473f1a3d54e7?w=400&q=80", desc: "Tomato-flavored Maggi seasoning, rich taste and color." },
  { name: "TI MALICE MAMIT",             price: 12.00, orig: 13.00, cat: "condiments", img: "https://images.unsplash.com/photo-1559181567-c3190ef65ea5?w=400&q=80", desc: "Traditional Haitian hot sauce / peanut seasoning." },
  { name: "Pitimi Seasoning (Mamit)",    price:  7.50, orig:  8.50, cat: "condiments", img: "https://images.unsplash.com/photo-1532336414038-cf19250c5757?w=400&q=80", desc: "A must-have seasoning ingredient for Haitian cooking." },

  // DRINKS
  { name: "Gatorade Drink 3 CT",         price:  6.00, orig:  7.00, cat: "drinks",     img: "https://images.unsplash.com/photo-1550539083-d9f999967d3d?w=400&q=80", desc: "Refreshing sports drink to stay hydrated and energized." },
  { name: "Shake Bongu 3 CT",            price:  6.00, orig:  7.00, cat: "drinks",     img: "https://images.unsplash.com/photo-1541658016709-82835332156f?w=400&q=80", desc: "Refreshing sport shake, perfect for energy and hydration." },

  // PACKAGES
  { name: "Lamanjay Basic Package",      price: 149.00, orig: 150.00, cat: "packages", img: "https://images.unsplash.com/photo-1542838132-92c53300491e?w=400&q=80", desc: "Starter essentials package for one person or a small household." },
  { name: "Lafanmi Family Package",      price: 249.00, orig: 250.00, cat: "packages", img: "https://images.unsplash.com/photo-1488459716781-31db52582fe9?w=400&q=80", desc: "Complete family grocery package with all the essentials.", popular: true },
  { name: "Kè Kontan Premium Package",   price: 287.00, orig: 288.00, cat: "packages", img: "https://images.unsplash.com/photo-1607082348824-0a96f2a4b9da?w=400&q=80", desc: "Premium package with extras including meat, flowers, and more." },

  // OTHER
  { name: "BONBON SèL",                  price:  2.00, orig:  3.00, cat: "other",      img: "https://images.unsplash.com/photo-1582058091505-f87a2e55a40f?w=400&q=80", desc: "Sweet and salty candy, loved by kids and adults alike." },
  { name: "Flower Bouquet",              price: 59.00, orig: 60.00, cat: "other",      img: "https://images.unsplash.com/photo-1487530811015-780780f03e2c?w=400&q=80", desc: "Beautiful fresh flower bouquet, perfect for gifts and occasions." },
];

// ---- RENDER PRODUCTS ----
function renderProducts(cat) {
  const grid = document.getElementById('productGrid');
  const countEl = document.getElementById('productCount');
  const filtered = cat === 'all' ? PRODUCTS : PRODUCTS.filter(p => p.cat === cat);
  countEl.textContent = filtered.length + ' item' + (filtered.length !== 1 ? 's' : '');

  grid.innerHTML = filtered.map(p => `
    <div class="product-card">
      <div class="product-img-wrap">
        ${p.popular ? '<span class="badge">Popular</span>' : ''}
        <img src="${p.img}" alt="${p.name}" loading="lazy" onerror="this.parentElement.classList.add('img-fallback')"/>
      </div>
      <div class="product-body">
        <p class="product-name">${p.name}</p>
        <p class="product-desc">${p.desc}</p>
        <div class="product-footer">
          <div><span class="price">$${p.price.toFixed(2)}</span><span class="price-old">$${p.orig.toFixed(2)}</span></div>
          <button class="add-btn" onclick="orderWhatsApp('${p.name.replace(/'/g,"\\'")}', '${p.price.toFixed(2)}')">Order</button>
        </div>
      </div>
    </div>
  `).join('');
}

// ---- WHATSAPP ORDER ----
function orderWhatsApp(name, price) {
  const msg = encodeURIComponent(`Hi, I'd like to order: ${name} ($${price}). Please confirm availability and delivery details for Port-au-Prince.`);
  window.open(`https://wa.me/50944708000?text=${msg}`, '_blank');
}

// ---- FILTER TABS ----
document.getElementById('filterTabs').addEventListener('click', e => {
  if (!e.target.matches('.filter-btn')) return;
  document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
  e.target.classList.add('active');
  renderProducts(e.target.dataset.cat);
});

// ---- MOBILE NAV ----
const navToggle = document.querySelector('.nav-toggle');
const navLinks  = document.getElementById('navLinks');
if (navToggle) {
  navToggle.addEventListener('click', () => navLinks.classList.toggle('open'));
  navLinks.querySelectorAll('a').forEach(l => l.addEventListener('click', () => navLinks.classList.remove('open')));
}

// ---- CONTACT FORM ----
function handleForm(e) {
  e.preventDefault();
  const success = document.getElementById('formSuccess');
  if (success) {
    success.style.display = 'block';
    e.target.reset();
    setTimeout(() => { success.style.display = 'none'; }, 4000);
  }
}

// ---- INIT ----
renderProducts('all');
